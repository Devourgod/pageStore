import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
    <h1>你好，我是React，很高兴遇见你</h1>
    ,
    document.querySelector('#app')
);

