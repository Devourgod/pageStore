import React, { Component } from 'react'

export default class App extends Component {
    constructor() {
        super();

        this.state = {
            a: 10
        };
    }
    render() {
        return (
            <div>
                <h1>{this.state.a}</h1>
                
                <button onClick={()=>{
                    this.setState({
                        a: this.state.a + 1
                    });
                }}>按我加1</button>

                <button onClick={()=>{
                    this.setState({
                        a: this.state.a - 1
                    })
                }}>按我减1</button>
            </div>
        )
    }
}
