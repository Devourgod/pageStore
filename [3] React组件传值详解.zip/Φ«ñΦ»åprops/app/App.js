import React, { Component } from 'react';

import Compo from './Compo.js';

export default class App extends Component {
    constructor(){
        super();
        this.state = {
            a: 10
        };
    }

    // 加函数
    jia(){
        this.setState({
            a: this.state.a + 1
        });
    }

    render() {
        return (
            <div>
                <Compo a={this.state.a} jia={this.jia.bind(this)} />
            </div>
        )
    }
}
