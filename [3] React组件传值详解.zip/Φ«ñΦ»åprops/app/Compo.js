import React, { Component } from 'react'

export default class Compo extends Component {
    render() {
        return (
            <div>
                <h1>我是Compo组件， {this.props.a}</h1>
                <button onClick={()=>{
                    this.props.jia();
                }}>按我加1</button>
            </div>
        )
    }
}
