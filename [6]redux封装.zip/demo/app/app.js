import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button } from 'antd'//antd 是 ui 组件不用管
class app extends Component {
    render() {
        return (
            <div>
                //直接 props 调用
                <h1>{this.props.idx}</h1>
                <Button onClick={() => {
                    //直接 props 调用
                    this.props.dispatch({ 'type': 'ADD' })
                }}>按我加一</Button>
            </div>
        )
    }
}
//装饰器
export default connect(
    //传入state
    (state) => ({
        idx: state.jsqReducer.a
    })
    ,
    //传入 dispatch 函数
    (dispatch) => ({ dispatch })
)(app)
//两个括号 connect(函数,函数)(app)