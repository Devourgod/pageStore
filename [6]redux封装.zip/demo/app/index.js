import React from 'react'
import ReactDOM from 'react-dom'
import {createStore} from 'redux'
import {Provider} from 'react-redux'

import Reducers from './reducers/Reducers'
import App from './app'

//创建 store
const store =  createStore(Reducers)
console.log(store.getState().jsqReducer)
ReactDOM.render(
    //使用 recat-redux 组件包装自己的组件，并传入 store
    <Provider store={store}>
        <App/>
    </Provider>
    ,
    document.getElementById('app')
)