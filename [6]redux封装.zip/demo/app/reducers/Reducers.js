import {combineReducers} from 'redux'
import jsqReducer from './jsqReducer'
export default combineReducers({
    jsqReducer
})
