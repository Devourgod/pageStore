export default (state={a:10},action)=>{
    if(action.type="ADD"){
        return {
            ...state,
            a:state.a+1
        }
    }
    return state;           
}