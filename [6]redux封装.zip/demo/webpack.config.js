const path = require('path');

module.exports = {
	// mode：模式选择 development 属于开发模式下不压缩
	//production注重更小的 bundle，更轻量的 source map，以及更优化的资源，以改善加载时间。
	mode: 'development',
	//入口
	entry: './app/index.js',
	//输出
	output: {
		// 输出路径 path.resolve()用来拼接路径，__dirname 代表当前文件夹绝对路径
		publicPath: 'xuni',
		//打包出来的文件名称
		filename: 'bundle.js'
	},
	module: {
		rules: [
			{
				//正则匹配 .less 结尾的文件
				test: /\.less$/,
				//使用哪些加载器转换，倒序执行，也就是先使用 less-loader 刷一遍
				use: [
					{
						//npm i style-loader 下同
						loader: 'style-loader', // creates style nodes from JS strings
					},
					{	
						loader: 'css-loader', // translates CSS into CommonJS
					},
					{
						loader: 'less-loader', // compiles Less to CSS
						options: {
							//如果使用antd import antd 的less 要加这一天
							javascriptEnabled: true
						}
					},
				],
			},
			{
				//匹配.js 结尾的文件
				test: /\.m?js$/,
				//匹配 resource
				exclude: /(node_modules|bower_components)/,
				use: {
					loader: 'babel-loader',
					options: {
						//@babel/preset-env是 es6的转换 @babel/preset-react 是 react 的语法转换,开发模式可以不加，加快打包速度
						presets: ['@babel/preset-react'],
					}
				}
			}
		],
	},
};